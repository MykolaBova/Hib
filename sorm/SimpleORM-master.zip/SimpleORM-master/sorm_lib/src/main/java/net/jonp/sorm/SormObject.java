package net.jonp.sorm;

/**
 * Super-interface of all Sorm model objects.
 */
public interface SormObject
{
    // No actual content
}
