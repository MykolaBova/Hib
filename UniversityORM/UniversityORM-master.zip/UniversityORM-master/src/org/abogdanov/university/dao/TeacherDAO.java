package org.abogdanov.university.dao;

import org.abogdanov.university.domain.Teacher;

public interface TeacherDAO extends GenericDAO<Teacher> {

}
