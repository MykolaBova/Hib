package org.abogdanov.university.dao;

import org.abogdanov.university.domain.Subject;

public interface SubjectDAO extends GenericDAO<Subject> {

}
