package org.abogdanov.university.dao.impl;

import org.abogdanov.university.dao.ExamDAO;
import org.abogdanov.university.domain.Exam;

public class ExamDAOImpl
		extends GenericDAOImpl<Exam>
		implements ExamDAO {

}
