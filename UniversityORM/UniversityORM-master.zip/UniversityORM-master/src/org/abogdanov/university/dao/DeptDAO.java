package org.abogdanov.university.dao;

import org.abogdanov.university.domain.Dept;

public interface DeptDAO extends GenericDAO<Dept> {

}
