package org.abogdanov.university.dao;

import org.abogdanov.university.domain.Exam;

public interface ExamDAO extends GenericDAO<Exam> {
}
