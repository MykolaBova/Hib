package org.abogdanov.university.dao;

import org.abogdanov.university.domain.Student;

public interface StudentDAO extends GenericDAO<Student> {


}
