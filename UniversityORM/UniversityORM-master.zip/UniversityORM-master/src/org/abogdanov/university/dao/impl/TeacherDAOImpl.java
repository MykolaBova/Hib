package org.abogdanov.university.dao.impl;

import org.abogdanov.university.dao.TeacherDAO;
import org.abogdanov.university.domain.Teacher;

public class TeacherDAOImpl
		extends GenericDAOImpl<Teacher>
		implements TeacherDAO {
}
