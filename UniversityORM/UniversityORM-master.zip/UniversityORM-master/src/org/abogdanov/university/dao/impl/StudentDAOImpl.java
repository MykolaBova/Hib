package org.abogdanov.university.dao.impl;

import org.abogdanov.university.dao.StudentDAO;
import org.abogdanov.university.domain.Student;

public class StudentDAOImpl
		extends GenericDAOImpl<Student>
		implements StudentDAO {

}
