package org.abogdanov.university.dao.impl;

import org.abogdanov.university.dao.SubjectDAO;
import org.abogdanov.university.domain.Subject;

public class SubjectDAOImpl
		extends GenericDAOImpl<Subject>
		implements SubjectDAO {

}
