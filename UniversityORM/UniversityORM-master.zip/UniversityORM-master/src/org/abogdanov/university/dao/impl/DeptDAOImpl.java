package org.abogdanov.university.dao.impl;

import org.abogdanov.university.dao.DeptDAO;
import org.abogdanov.university.domain.Dept;

public class DeptDAOImpl
		extends GenericDAOImpl<Dept>
		implements DeptDAO {

}
