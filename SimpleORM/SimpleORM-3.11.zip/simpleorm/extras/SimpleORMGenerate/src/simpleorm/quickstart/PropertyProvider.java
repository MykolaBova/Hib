package simpleorm.quickstart;

public interface PropertyProvider {
	public String getProperty(String p);
	public String getProperty(String p, String def);
}
