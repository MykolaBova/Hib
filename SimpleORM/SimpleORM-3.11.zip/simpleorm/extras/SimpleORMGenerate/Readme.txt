Richard Schmidt's SimpleORM QuickStart/Generator

This Utility can interrogate JDBC meta data of a pre-existing database and generate record definitions.

See the javadocs for details.

richard.schmidt@solution6.com

Modified by Martin Holst Swende 2008 : 
Created bundling (optional ) as ant-task
Updated to work with SimpleORM 3.X
martin at swende dot se

