package org.julp.gui.swing.menu;

public class TextEditMenu {
    
    public TextEditMenu() {
    }
}
