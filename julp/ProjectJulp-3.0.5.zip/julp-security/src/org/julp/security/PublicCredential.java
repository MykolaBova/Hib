package org.julp.security;

import javax.security.auth.Destroyable;
import javax.security.auth.Refreshable;

public abstract class PublicCredential implements Refreshable, Destroyable{ 

    public PublicCredential() {
    }
    
}
