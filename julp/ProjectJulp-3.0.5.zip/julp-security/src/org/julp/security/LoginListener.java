package org.julp.security;

import java.beans.PropertyChangeListener;

public class LoginListener implements PropertyChangeListener {

    public LoginListener() {
    }

    @Override
    public void propertyChange(java.beans.PropertyChangeEvent propertyChangeEvent) {
        //propertyChangeEvent.
    }
}
