package org.julp;

public enum PersistentState {
    ORIGINAL, CREATED, STORED, REMOVED, UNDEFINED;
}
