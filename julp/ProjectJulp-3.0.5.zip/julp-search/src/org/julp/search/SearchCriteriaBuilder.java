package org.julp.search;

/** Implementation of AbstractSearchCriteriaBuilder. Extend as needed */
public class SearchCriteriaBuilder extends AbstractSearchCriteriaBuilder {

    public SearchCriteriaBuilder() {
    }
}
