package org.orman.exception;

@SuppressWarnings("serial")
public class FeatureNotImplementedException extends OrmanException {

	public FeatureNotImplementedException(String message) {
		super(message);
	}

}
