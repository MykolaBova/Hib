package org.orman.sql;

public interface ISubclause {
	public String getClauseFormat();
	public String toString();
}