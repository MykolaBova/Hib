package org.orman.sql;

public interface Aliasable {
	public String getAlias();
}
