package org.orman.sql;

public enum LogicalOperator {
	AND, OR
}
