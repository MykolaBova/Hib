package com.dclonline.db;

/**
 * Marker interface to facilitate 'Java Generics'
 *
 */
public interface TableDefinition {

}
