package net.sourceforge.pbeans;

public interface BeanFactory<T> {
	public T create();
}
