public enum MyEnum {
	BLACK, WHITE, RED, GREEN, BLUE;
}
