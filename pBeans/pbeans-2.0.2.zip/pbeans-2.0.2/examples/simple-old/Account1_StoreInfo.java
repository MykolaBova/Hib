import net.sourceforge.pbeans.AbstractStoreInfo;

public class Account1_StoreInfo extends AbstractStoreInfo {
	public Account1_StoreInfo() {
		super(Account1.class);
	}
}
